// Optional: Handle events or background logic if needed
chrome.runtime.onInstalled.addListener(() => {
  console.log('Extension installed');
});
